<?php
require_once "./pusher.php";
require_once "./mvc/core/App.php";
require_once "./mvc/core/Controller.php";
require_once "./mvc/core/DB.php";
require_once "./mvc/core/Config.php";
require_once "./mvc/pkg/validator.php";
require_once "./mvc/pkg/mail.php";
require_once "./mvc/pkg/format.php";
require_once "./mvc/pkg/encryption.php";
require_once "./mvc/pkg/upload.php";
require_once "./mvc/pkg/alert.php";
?>