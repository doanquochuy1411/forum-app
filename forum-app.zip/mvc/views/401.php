<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/client/css/404.css">
    <title>Không có quyền truy cập</title>
</head>

<body>
    <div class="container">
        <h1>401</h1>
        <p>Không có quyền truy cập</p>
        <a href="<?php echo BASE_URL; ?>">Trở lại</a>
    </div>
</body>

</html>